import React from 'react';
import { useState } from 'react';
import { redirect } from 'react-router-dom';
// import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';



 function MyMainLogin(){

    const navigate = useNavigate();
    const redirectToLogin = () => {
        navigate('/signup');
    }

    const navigate1 = useNavigate();
    const redirectToUser = () => {
        navigate1('/userlog');
    }

    const navigate2=useNavigate();
    const redirectToNgo=()=>{
        navigate2('/ngolog');

    }

    return(
        <div className='container'>
            <h1>Login for a User or NGO?</h1>
            <label htmlFor='UserLogin'>User: </label><br></br>
            <button id='UserLogin'className='btn btn-primary btnstyle' onClick={redirectToUser}>User</button><br></br><br></br>
            <label htmlFor='NgoLogin'>NGO: </label><br></br>
            <button id='NgoLogin'className='btn btn-primary btnstyle'onClick={redirectToNgo}>NGO</button><br></br><br></br>
            <div>
                <label htmlFor='singup'>Need an account?</label>
                <button className='btn btn-primary' type='submit' onClick={redirectToLogin}>SignUp</button>
            </div>
        </div>
        
    )

 }
 export default MyMainLogin;
 





















