import React from "react";

function MyUserLogin(){
    return(
        <div className="container">
            <h1>UserLogin</h1>
            <form>
                <label htmlFor="email">Email Id:</label>
                <input className="form-control" type="email" id="email" name="email" placeholder="Enter Email"></input><br></br>

                <label htmlFor="phone">Phone No:</label>
                <input className="form-control" type="text" id="phone" name="phone" placeholder="Enter Phone No"></input><br></br>

                <button className="btn btn-primary" type="submit">Send OTP</button>
            </form>
        </div>
    )
}
export default MyUserLogin;

//sample
// function MyLogin() {

//     //routing purpose
//     const navigate = useNavigate();
//     const redirectToRegister = () => {
//         navigate('/signup');
//     }

//     // define state variables
//     const [email, setEmail] = useState('');
//     const [password, setPassword] = useState('');

//     //evnet handling
//     const handleFormSubmit = (e) => {
//         e.preventDefault();
//         console.log(email, password);
//         console.log(e);
//     }


//     return (
//         <div className="container">
//             <h1>Login Page</h1>
//             <form onSubmit={handleFormSubmit}>

//                 <label htmlFor="email">Email Id: </label><br></br>
//                 <input type="email" className="form-control" placeholder="Enter Username" id="email" name="email" value={email} onChange={(e) => setEmail(e.target.value)}/><br /><br />

//                 <label htmlFor="password">Password: </label><br></br>
//                 <input type="password" className="form-control" placeholder="Enter Password" id="password" name="password" value={password} onChange={(e) => setPassword(e.target.value)}/><br /><br />

//                 <button type="submit" className="btn btn-primary" value="Login">Login</button><br></br><br></br>

//                 <label htmlFor="signup">Need an account?</label><br></br>
//                 <button id="signup" className="btn btn-primary" onClick={redirectToRegister}>Sign Up</button>
//             </form>
//         </div>

//     )
// }
// export default MyLogin;