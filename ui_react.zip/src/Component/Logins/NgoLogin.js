import React from "react";

function MyNgoLogin(){
    return(
        <div className="container">
            <h1>NGO Login</h1>
            <label htmlFor="RefNo">NGO Refference No:</label>
            <input className="form-control" type="text" id="RefNo" name="RefNo" placeholder="Enter Reference No"></input><br></br>
            <label htmlFor="email">Email Id:</label>
            <input className="form-control" type="email" id="email" name="email" placeholder="Enter Email"></input><br></br><br></br>
            <button className="btn btn-primary" type="submit">Send OTP</button>
        </div>
    )
}
export default MyNgoLogin;
