import React from "react";
import backgroundimg from "../../images/background.jpg";
import FearImg from "../../images/sec1.jpg";
import VisionImg from "../../images/vission.jpg";
import MissionImg from "../../images/mission.jpg";
import CAPACITYDEVELOPMENT from "../../images/Capacity-Development.png";
import COMMUNITYENGAGEMENT from "../../images/Community-Engagement.png";
import EVIDENCEBUILDING from "../../images/Evidence-Building.png";
import TECHNICALASSISTANCE from "../../images/Technical-Assistance.png"
import '../../styles/home.css';



// import { useNavigate } from "react-router-dom";
function MyHome() {
    return (
        <div>
            {/* <h1>this is home</h1> */}


            <img id="bgimg" src={backgroundimg} alt="home image"></img>
            
            <section id="SectionAbout">

                <section id="first">

                    <div className="SectionParadiv">
                        <p className="BigText">What is SafeHer ?</p>
                        <p className="SmallText">
                            SafetHer is a social impact organization working towards Building Responsive,
                            Inclusive, Safe, and Equitable Communities. We collaborate with government and
                            non-government stakeholders in using big data to improve infrastructure and services in cities.
                        </p>
                    </div>
                    <div className="SectionImgdiv">
                        <img className="SectionImg" src={FearImg} alt="Fear Image"></img>
                    </div>

                </section>

                <section id="second">
                    <div className="SectionParadiv">
                        <p className="BigText">Our Vision</p>
                        <p className="SmallText">Our vision is to empower women to travel confidently, making fearless,
                            independent explorers, and to create a world where every woman can journey with confidence and
                            discover boundless horizons.

                        </p>
                    </div>

                    <div className="SectionImgdiv">
                        <img className="SectionImg" src={VisionImg} alt="Vision image"></img>
                    </div>

                </section>

                <section id="third">

                    <div className="SectionParadiv">
                        <p className="BigText">Our Mission</p>
                        <p className="SmallText">
                            Our mission is to empower women for safer travel with our location-based review system.
                            We provide real-time safety information, anonymous reviews, and a supportive community,
                            creating a safer world for women to explore with confidence.
                        </p>
                    </div>

                    <div className="SectionImgdiv">
                        <img className="SectionImg" src={MissionImg} alt="Vission Image"></img>
                    </div>

                </section>

                <div id="fourth">
                    <p className="BigText">Our Services</p>
                </div>
                
                <section>
                    <div id="horizontal-container">
                        <div className="ServiceDiv">

                            <div className="ServiceImgDiv">
                                <img className="ServiceImg" src={CAPACITYDEVELOPMENT} alt="CD"></img>
                            </div>

                            <div >
                                <p className="ServiceText">CAPACITY DEVELOPMENT</p>
                            </div>

                        </div>
                        <div className="ServiceDiv">

                            <div id="Secondimgdiv" className="ServiceImgDiv">
                                <img className="ServiceImg" src={COMMUNITYENGAGEMENT} alt="CE"></img>
                            </div>

                            <div>
                                <p className="ServiceText">COMMUNITY ENGAGEMENT</p>
                            </div>

                        </div>

                        <div className="ServiceDiv">

                            <div className="ServiceImgDiv">
                                <img className="ServiceImg" src={EVIDENCEBUILDING} alt="EB"></img>
                            </div>

                            <div>
                                <p className="ServiceText">EVIDENCE BUILDING</p>
                            </div>
                        </div>

                        <div className="ServiceDiv">

                            <div className="ServiceImgDiv">
                                <img className="ServiceImg" src={TECHNICALASSISTANCE} alt="TA"></img>
                            </div>

                            <div>
                                <p className="ServiceText">TECHNICAL ASSISTANCE</p>
                            </div>
                        </div>

                    </div>
                    

                </section>

            </section>
        </div>
    )
}
export default MyHome;
