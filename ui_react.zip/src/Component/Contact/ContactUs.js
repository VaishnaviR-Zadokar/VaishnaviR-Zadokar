import React, { useState } from "react";
function MyContact() {

  // define state variables
  const [fname, setFname] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  //evnet handling
  const handleFormSubmit = (e) => {
    e.preventDefault();
    console.log(fname, email, phone, message);
    console.log(e);
    setFname('');
    setEmail('');
    setPhone('');
    setMessage('');
  }


  return (
    <div className="container">
      <form onSubmit={handleFormSubmit}>
        <h1>Contact Us</h1>

        <label htmlFor="fname">Name:</label>
        <input className="form-control" type="text" name="fname" id="fname" placeholder="Enter your name" value={fname} onChange={(e) => setFname(e.target.value)}></input><br></br>

        <label htmlFor="email">Email Id:</label>
        <input className="form-control" type="email" name="email" id="email" placeholder="Enter your Email" value={email} onChange={(e) => setEmail(e.target.value)}></input><br></br>

        <label htmlFor="phone">Phone No:</label>
        <input className="form-control" type="text" name="phone" id="phone" placeholder="Enter Phone No" value={phone} onChange={(e) => setPhone(e.target.value)}></input><br></br>

        <label htmlFor="message"></label>
        <textarea className="form-control" id="message" name="message" rows={4} cols={15} placeholder="How can we help you?" value={message} onChange={(e) => setMessage(e.target.value)}></textarea><br></br>

        <button className="btn btn-primary" id="submit">Submit</button>
      </form>

    </div>
  )
}
export default MyContact;