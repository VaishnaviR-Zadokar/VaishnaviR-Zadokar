import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';

function MyUserSign() {

    // //routing purpose
    // const navigate = useNavigate();
    // const redirectToLogin = () => {
    //     navigate('/login');
    // }

    // define state varibles
    // const [name, setName] = useState('');
    // const [email, setEmail] = useState('');
    // const [phone, setPhone] = useState('');
    // const [password, setPassword] = useState('');

    return (
        <div className="container">

            <form >
                <h1>User Signup</h1>
                <label htmlFor="fname">Name: </label><br />
                <input type="text" className="form-control" id="fname" name="fname" placeholder="Enter Full Name"></input><br />


                <label htmlFor="email">Email Id: </label><br />
                <input type="email" className="form-control" id="email" name="email" placeholder="Enter Email"></input><br />

                <label htmlFor="phone">Phone number: </label><br />
                <input type="text" className="form-control" id="phone" name="phone" placeholder="Enter Phone No"></input><br />

                <button className="btn btn-primary" type="submit">Send OTP</button><br></br>

                {/* <label htmlFor="login">already Registered?</label> */}
                {/* <button className="btn btn-primary" id="login" onClick={redirectToLogin}>Login</button> */}

            </form>
        </div>
    )
}
export default MyUserSign;