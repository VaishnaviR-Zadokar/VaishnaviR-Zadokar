import React from "react";

function MyNgoSign(){

    
    return(
        <div className="container">
            <form >
                <h1>NGO Signup</h1>

                <label htmlFor="fname">Name: </label><br />
                <input type="text" className="form-control" id="fname" name="fname" placeholder="Enter NGO Name"></input><br />

                <label htmlFor="RefNo">Reference number: </label><br />
                <input type="text" className="form-control" id="RefNo" name="RefNo" placeholder="Enter Reference No"></input><br />

                <label htmlFor="email">Email Id: </label><br />
                <input type="email" className="form-control" id="email" name="email" placeholder="Enter Email"></input><br />


                <button className="btn btn-primary" type="submit">Send OTP</button><br></br>
                </form>
        </div>
    )
}
export default MyNgoSign;
