import React from "react";
function MyResource(){
    return(
        <div>
            <h1>This is resource</h1>
        </div>
    )
}
export default MyResource;