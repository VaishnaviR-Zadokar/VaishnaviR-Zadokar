import { Link } from "react-router-dom";
import React from "react";
function MyNav() {
    return (
        <nav className="navbar navbar-expand-sm bg-light sticky-navbar">

            <div className="container-fluid navbg">

                <ul className="navbar-nav ">

                    <li className="nav-item ">
                        <Link className="nav-link navitems hover-items" to="/">Home</Link>
                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems hover-items" to="/map">Map</Link>

                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems " to="/resources">Resources</Link>
                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems " to="/about">About</Link>
                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems " to="/contact">Contact Us</Link>
                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems " to="/login">Log In</Link>
                    </li>

                    <li className="nav-item ">
                        <Link className="nav-link navitems " to="/signup">Sign up</Link>
                    </li>

                </ul>
            </div>
            <div id="SearchDiv">
                <input type="text" name="search " id="SearchInput" placeholder="Enter address"></input>
                <button type="submit" name="search" id="SearchBtn">Search</button>
            </div>
        </nav>
    )
}
export default MyNav;