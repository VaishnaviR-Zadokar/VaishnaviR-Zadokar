import React from "react";
import MyNav from "./Component/nav/nav";
import MyHome from "./Component/home/home";
import MyResource from "./Component/Resources/Resources";
import Myabout from "./Component/about/about";
import MyContact from "./Component/Contact/ContactUs";
import MyMainLogin from "./Component/Logins/login";
import MyUserLogin from "./Component/Logins/UserLogin";
import MyNgoLogin from "./Component/Logins/NgoLogin";
import Myform from "./Component/Forms/form";
import MyUserSign from "./Component/Forms/UserSign";
import MyNgoSign from "./Component/Forms/NgoSign";
import { Routes, Route } from 'react-router-dom';
import Mymap from "./Component/map/map";


// import MyMap from "./Component/Map/map";

// function App() {
//     return (
//         <MyNav />,
//         <Routes>
//             <Route path="/" element={<MyLogin />} />
//             <Route path="/signup" element={<Myform />} />
//             {/* <Route index element={<MyLogin />} /> Default route */}


//         </Routes>

//     )
// }
// export default App;

// chatgpt
function App() {
    return (
        <>

            {/* <MyHome /> */}
            <MyNav />
            <Routes>
                <Route path="/" element={<MyHome />} />
                <Route path="/map" element={<Mymap />} />
                <Route path="/resources" element={<MyResource />} />
                <Route path="/about" element={<Myabout />} />
                <Route path="/contact" element={<MyContact />} />
                {/* <Route path="/map" element={<MyMap />}/> */}
                <Route path="/login" element={<MyMainLogin />} />
                <Route path="/userlog" element={<MyUserLogin/>}/>
                <Route path="/ngolog" element={<MyNgoLogin/>}/>
                <Route path="/signup" element={<Myform />} />
                <Route path="/usersign" element={<MyUserSign/>}/>
                <Route path="ngosign" element={<MyNgoSign/>}/>

                {/* <Route index element={<MyLogin />} /> Default route */}

                {/* <Route path="/home" element={<MyHome />} />
                <Route path="/nav" element={<MyNav />} /> */}
            </Routes>
        </>
    )
}
export default App;



